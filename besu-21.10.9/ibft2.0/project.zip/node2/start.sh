../../bin/besu --config-file=../config.toml --p2p-port=30304 --rpc-http-enabled --rpc-http-port=8546 
