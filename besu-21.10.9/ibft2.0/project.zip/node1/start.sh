../../bin/besu --data-path=./data --genesis-file=../genesis.json --p2p-port=30303 --rpc-http-enabled --rpc-http-port=8545
